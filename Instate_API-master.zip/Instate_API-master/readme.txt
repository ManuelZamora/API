coneccion = proyecto
direccionamiento = aplicacin

scikit-image
mysqlclient
gmaps
pandas
numpy
cv2
django
