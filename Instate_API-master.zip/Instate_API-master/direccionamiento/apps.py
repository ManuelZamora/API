from django.apps import AppConfig


class DireccionamientoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'direccionamiento'
